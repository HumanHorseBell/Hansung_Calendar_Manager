package com.example.humanbell

class TodoListAdapter {

//이 부분은 list view 넣어 줘야함
}