package com.humanhorsebell.computer.hansung_calendar_manager

import com.orhanobut.dialogplus.DialogPlus

class CustomDialog2 {

}
