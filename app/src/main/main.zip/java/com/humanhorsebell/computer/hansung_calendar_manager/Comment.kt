package com.humanhorsebell.computer.hansung_calendar_manager

data class Comment(
    val data: String,
    val mTime: String,
    val pictureURL: String,
    val writer: String
)
