package com.humanhorsebell.computer.hansung_calendar_manager

data class Group(
        val grpNum: String,
        val grpName: String,
        val grpMem: ArrayList<String>
)